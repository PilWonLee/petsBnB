package com.drew.execute;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import com.drew.imaging.ImageMetadataReader;
import com.drew.metadata.Directory;
import com.drew.metadata.Metadata;
import com.drew.metadata.Tag;

public class Execute {

	public Map<String, Object> Analysis(File file)throws Exception{
		Map<String, Object> result = new HashMap<>();
		
		 //read file info
	    Metadata metadata = ImageMetadataReader.readMetadata(file);
	    StringBuffer findSomthing = new StringBuffer();
	    for (Directory directory : metadata.getDirectories()) {
	        for (Tag tag : directory.getTags()) {
	            if(tag.toString().substring(0,10).equals("[PNG-tEXt]")) {
	            	findSomthing.append(tag.toString().split("-")[2].replaceAll(" ", ""));
	            	findSomthing.append(",");
	            	result.put(tag.toString().split("-")[2].replaceAll(" ", "").split(":")[0], tag.toString().split("-")[2].replaceAll(" ", "").split(":")[1]);
	            }
	        }
	    }
		
		return result;
	}
	
}
